import React from "react";
import Quiz from "./Quiz";

export default function App() {
  return (
    <>
      <Quiz/>
    </>
  );
}